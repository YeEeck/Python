print('123')
